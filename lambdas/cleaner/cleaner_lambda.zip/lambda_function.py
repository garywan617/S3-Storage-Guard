import boto3
import os

s3 = boto3.client('s3')
bucket_name = os.environ.get("BUCKET_NAME")

def lambda_handler(event, context):
    THRESHOLD = 15 * 1024  # 15 KB in bytes
    
    # 1. 列出 bucket 裡所有物件
    response = s3.list_objects_v2(Bucket=bucket_name)
    if 'Contents' not in response:
        print("Bucket is empty")
        return


    # 2. 計算 bucket 的總大小
    total_size = sum(obj['Size'] for obj in response['Contents'])
    print(f"Total bucket size: {total_size} bytes ({total_size / 1024:.2f} KB)")

    if total_size <= THRESHOLD:
        print(f"Bucket size is below threshold ({total_size} bytes <= {THRESHOLD} bytes)")
        return

    # 3. 若有單一檔案 > 15KB，優先刪除該檔案（刪除一個）
    oversized_files = [obj for obj in response['Contents'] if obj['Size'] > THRESHOLD]
    if oversized_files:
        oversized_obj = max(oversized_files, key=lambda x: x['Size'])
        s3.delete_object(Bucket=bucket_name, Key=oversized_obj['Key'])
        total_size -= oversized_obj['Size']
        print(
            f"Deleted oversized object: {oversized_obj['Key']} "
            f"(Size: {oversized_obj['Size']} bytes)"
        )
        print(f"New total bucket size: {total_size} bytes ({total_size / 1024:.2f} KB)")
        return

    # 4. 否則，刪除 LRU 物件直到總大小 <= 15KB
    while total_size > THRESHOLD:
        # 重新列出物件，以獲取最新的清單
        response = s3.list_objects_v2(Bucket=bucket_name)
        if 'Contents' not in response or len(response['Contents']) == 0:
            print("Bucket is now empty")
            break

        # 找出最少最近使用的檔案 (LRU - 最早改動的檔案)
        lru_obj = min(response['Contents'], key=lambda x: x['LastModified'])

        # 刪除 LRU 檔案
        s3.delete_object(Bucket=bucket_name, Key=lru_obj['Key'])
        print(f"Deleted LRU object: {lru_obj['Key']} (Size: {lru_obj['Size']} bytes)")

        # 更新總大小
        total_size -= lru_obj['Size']
        print(f"New total bucket size: {total_size} bytes ({total_size / 1024:.2f} KB)")

    if total_size <= THRESHOLD:
        print(f"Bucket size is now below threshold ({total_size} bytes <= {THRESHOLD} bytes)")
