import json
import boto3
import logging
import time
import os

logs_client = boto3.client('logs')

LOG_GROUP_NAME = f"/aws/lambda/{os.environ['AWS_LAMBDA_FUNCTION_NAME']}"

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    print(event)
    for record in event['Records']:
        # 解析 SQS 中的 body 字段，這裡包含 SNS 消息
        sns_message = json.loads(record['body'])
        # 獲取 SNS 消息中的 Message 字段，它包含了 S3 事件
        s3_event = json.loads(sns_message['Message'])
        
        # 確認事件的結構
        logger.info(f"Parsed S3 event: {json.dumps(s3_event)}")
        
        for s3_record in s3_event.get('Records', []):
            event_name = s3_record['eventName']
            object_key = s3_record['s3']['object']['key']

            if event_name.startswith('ObjectCreated'):
                size = s3_record['s3']['object']['size']
                log_msg = {
                    "object_name": object_key,
                    "size_delta": size
                }
                logger.info(json.dumps(log_msg))

            elif event_name.startswith('ObjectRemoved'):
                size = get_previous_size(object_key)
                if size is not None:
                    log_msg = {
                        "object_name": object_key,
                        "size_delta": -size
                    }
                    logger.info(json.dumps(log_msg))
                else:
                    logger.warning(f"Size for deleted object {object_key} not found.")

def get_previous_size(object_key):
    try:
        # Search for log events from the past 5 days (this period can be adjusted)
        now = int(time.time())
        ten_minute = 10 * 60
        start_time = now - ten_minute

        response = logs_client.filter_log_events(
            logGroupName=LOG_GROUP_NAME,
            filterPattern=f'{{ $.object_name = "{object_key}" }}',  # Filter for log events containing the object key
            startTime=start_time,
            limit=20  # Limit to the most recent 5 events
        )
        
        events = response.get('events', [])
        if events:
            # 按 timestamp 排序，取出最新的一筆
            latest_event = max(events, key=lambda x: x['timestamp'])
    

            message = latest_event.get('message', '')


            try:
                # 通过 tab 分隔并提取出最后一部分，即 JSON 字符串
                log_parts = message.split("\t")  # 按 tab 分割
                json_string = log_parts[-1].strip()  # 获取最后一部分，并去除前后空格
    
                # 解析 JSON 字符串
                parsed_message = json.loads(json_string)
    
                # 检查 object_name 是否与 object_key 匹配
                if parsed_message.get('object_name') == object_key:
                    size = parsed_message.get('size_delta')
                    if isinstance(size, int) and size > 0:
                        return size
            except json.JSONDecodeError as json_err:
                logger.error(f"Error parsing message: {message}, error: {json_err}")

    except Exception as e:
        logger.error(f"Error retrieving size for {object_key}: {str(e)}")
    
    return None